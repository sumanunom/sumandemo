<?php
  session_start();
require_once "./functions/admin.php";
  $title = "PRODUCTS";
 
  require_once "./functions/database_functions.php";
  $conn = db_connect();
  $result = getAll($conn);
?>

<html lang="en">
<head>
  <title>Home Page</title>
  <link href="https://fonts.googleapis.com/css?family=Montserrat:900" rel="stylesheet">
   <link href="https://fonts.googleapis.com/css?family=Roboto:500" rel="stylesheet">

  <link rel="stylesheet" type="text/css" href="css/bootstrap/bootstrap.css">


 
  <style>
    
    div{
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;

}

  li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none!important;
  font-family: "Times New Roman", Times, serif;
}

li{
float:left;
}

li a:hover {
  background-color: white ;
  border-color: white;
}

body{
  background-color: lightblue;
}
.col-md-2{
  background:#2F404F;
  height: 100vh;
  width:auto;
  position:fixed;
  
   }

   .row-md-2{
    background:#2F404F;
  height: auto;
  width:165vh;
  position:relative;
   }
  
  #content {
  width: 100%;
  position: relative;
  margin-right: 0;
}


#viewport {
  padding-left: 250px;
  -webkit-transition: all 0.5s ease;
  -moz-transition: all 0.5s ease;
  -o-transition: all 0.5s ease;
  transition: all 0.5s ease;
}
.lead{
  color: orange;
}

form{
  height: auto;
  width: auto;
  padding-right: 250px;
  border-style:solid ;
  padding: 15px;
  border-radius: 10px;

}

  </style>
  
</head>
<body>


<!-- Wrapper -->
  <div class="wrapper" id="box"> 
<!-- Sidebar -->
    
      
   
    <div class="col-md-2">    

            <li><a href="#">DASHBOARD</a></li>
            <li><a href="admin.php">ADMIN LOGIN</a></li>
            <li><a href="foods.php">PRODUCT</a></li>
            <li><a href="#">CUSTOMER</a></li>
            <li><a href="#">ORDER</a></li>
            <li><a href="#">REPORTS</a></li>
          
    </div>
    </div>
   
<form action="" method="post">
 <div id="viewport">
<div id="content">
    <h1 align="center">Product Details</h1>
    <div class="container-fluid">

       
       <a class="btn btn-primary" href="admin_add.php">Add Product</a>
       
       <br>
        <div class="wrapper" id="box"> 
<!-- Sidebar -->
    <br>
      
    <div class="row-md-2">    

            <li><a href="#">General</a></li>
            <li><a href="#">Data</a></li>
            <li><a href="#">Stock</a></li>
            <li><a href="#">Attributrs</a></li>
            <li><a href="#">SEO</a></li>
            
          
    </div>
    </div>
   <br>

  <table class="table" style="margin-top: 20px">
    <tr>
      <th>List</th>
      <th>Product Name</th>
      <th>cheff</th>
      <th>Image</th>
      <th>Description</th>
      <th>Price</th>
      <!--<th>Restaurant</th>-->
      <th>&nbsp;</th>
      <th>&nbsp;</th>
    </tr>
    <?php while($row = mysqli_fetch_assoc($result)){ ?>
    <tr>
      <td><?php echo $row['item_no']; ?></td>
      <td><?php echo $row['food_name']; ?></td>
      <td><?php echo $row['cheff']; ?></td>
      <td><?php echo $row['food_image']; ?></td>
      <td><?php echo $row['food_descr']; ?></td>
      <td><?php echo $row['food_price']; ?></td>
        <td><a href="admin_edit.php?item_no=<?php echo $row['item_no']; ?>">Edit</a></td>
    </tr>
    <?php } ?>
  </table>

    </div>
  </div>

</div>




<div id="particles-js"></div>

    
  </div>

<!-- PreLoader -->
  <div id="preloader">
    <div id="status">&nbsp;</div>
  </div> 
<!-- PreLoader End -->
  
</div>
</form>
</body>
</html>