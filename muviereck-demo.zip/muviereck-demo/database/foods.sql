-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 23, 2022 at 01:12 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `foods`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `name` varchar(20) NOT NULL,
  `pass` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`name`, `pass`) VALUES
('admin', '123');

-- --------------------------------------------------------

--
-- Table structure for table `foods`
--

CREATE TABLE `foods` (
  `item_no` int(20) NOT NULL,
  `food_name` varchar(20) NOT NULL,
  `cheff` varchar(20) NOT NULL,
  `food_image` varchar(30) CHARACTER SET latin7 NOT NULL,
  `food_descr` varchar(100) NOT NULL,
  `food_price` int(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `foods`
--

INSERT INTO `foods` (`item_no`, `food_name`, `cheff`, `food_image`, `food_descr`, `food_price`) VALUES
(1, 'mutton biryani', 'tony', 'mutton.jpg', 'One kg mutton biryani is 300 r', 300),
(2, 'chicken biryani', 'dhamu', 'chicken.jpg', '1kg chicken biryani 150 Rupees', 150),
(3, 'dosa', 'stark', 'dosa.jpg', 'one dosa 40 rupees', 40),
(4, 'shawarma', 'dhamu', 'sha.jpg', 'one shawarma 100 rupees', 100),
(5, 'idly', 'dhamu', 'idly.jpg', '1 idly 8 rupees', 8);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
