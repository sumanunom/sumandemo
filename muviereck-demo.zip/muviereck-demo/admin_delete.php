<?php
	$book_isbn = $_GET['item_no'];

	require_once "./functions/database_functions.php";
	$conn = db_connect();

	$query = "DELETE FROM foods WHERE item_no = '$item_no'";
	$result = mysqli_query($conn, $query);
	if(!$result){
		echo "delete data unsuccessfully " . mysqli_error($conn);
		exit;
	}
	header("Location: admin_food.php");
?>