<?php
	session_start();
	require_once "./functions/admin.php";
	$title = "List Product";
	require_once "./template/header.php";
	require_once "./functions/database_functions.php";
	$conn = db_connect();
	$result = getAll($conn);
?>
	<p class="lead"><a href="admin_add.php">Add new Food</a></p>
	<a href="admin_signout.php" class="btn btn-primary">Sign out!</a>
	<table class="table" style="margin-top: 20px">
		<tr>
			<th>List</th>
			<th>Food Name</th>
			<th>cheff</th>
			<th>Image</th>
			<th>Description</th>
			<th>Price</th>
			<!--<th>Restaurant</th>-->
			<th>&nbsp;</th>
			<th>&nbsp;</th>
		</tr>
		<?php while($row = mysqli_fetch_assoc($result)){ ?>
		<tr>
			<td><?php echo $row['item_no']; ?></td>
			<td><?php echo $row['food_name']; ?></td>
			<td><?php echo $row['cheff']; ?></td>
			<td><?php echo $row['food_image']; ?></td>
			<td><?php echo $row['food_descr']; ?></td>
			<td><?php echo $row['food_price']; ?></td>
				<td><a href="admin_edit.php?item_no=<?php echo $row['item_no']; ?>">Edit</a></td>
			<td><a href="admin_delete.php?item_no=<?php echo $row['item_no']; ?>">Delete</a></td>
		</tr>
		<?php } ?>
	</table>

