<?php
  session_start();
  $item_no = $_GET['food'];
  // connecto database
  require_once "./functions/database_functions.php";
  $conn = db_connect();

  $query = "SELECT * FROM foods WHERE item_no = '$item_no'";
  $result = mysqli_query($conn, $query);
  if(!$result){
    echo "Can't retrieve data " . mysqli_error($conn);
    exit;
  }

  $row = mysqli_fetch_assoc($result);
  if(!$row){
    echo "Empty book";
    exit;
  }

  $title = $row['food_name'];
  require "./template/header.php";
?>
      <!-- Example row of columns -->
      <p class="lead" style="margin: 25px 0"><a href="foods.php">foods</a> > <?php echo $row['food_name']; ?></p>
      <div class="row">
        <div class="col-md-3 text-center">
          <img class="img-responsive img-thumbnail" src="./bootstrap/img/<?php echo $row['food_image']; ?>">
        </div>
        <div class="col-md-6">
          <h4>Food Description</h4>
          <p><?php echo $row['food_descr']; ?></p>
          <h4>Food Details</h4>
          <table class="table">
          	<?php foreach($row as $key => $value){
              if($key == "food_descr" || $key == "food_image" || $key == "food_name"){
                continue;
              }
              switch($key){
                case "item_no":
                  $key = "Item Number";
                  break;
                case "food_name":
                  $key = "Title";
                  break;
                case "cheff":
                  $key = "cheff";
                  break;
                case "food_price":
                  $key = "Price";
                  break;
              }
            ?>
            <tr>
              <td><?php echo $key; ?></td>
              <td><?php echo $value; ?></td>
            </tr>
            <?php 
              } 
              if(isset($conn)) {mysqli_close($conn); }
            ?>
          </table>
          <form method="post" action="cart.php">
            <input type="hidden" name="item_no" value="<?php echo $item_no;?>">
            <input type="submit" value="Click to Order / Add to cart" name="cart" class="btn btn-primary">
          </form>
       	</div>
      </div>
