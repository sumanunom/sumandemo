<?php
	function db_connect(){
		$conn = mysqli_connect("localhost", "root", "", "foods");
		if(!$conn){
			echo "Can't connect database " . mysqli_connect_error($conn);
			exit;
		}
		return $conn;
	}

	function select4LatestBook($conn){
		$row = array();
		$query = "SELECT item_no, food_image FROM foods ORDER BY item_no DESC";
		$result = mysqli_query($conn, $query);
		if(!$result){
		    echo "Can't retrieve data " . mysqli_error($conn);
		    exit;
		}
		for($i = 0; $i < 4; $i++){
			array_push($row, mysqli_fetch_assoc($result));
		}
		return $row;
	}

	function getBookByIsbn($conn, $item_no){
		$query = "SELECT food_name, cheff, food_price FROM foods WHERE item_no = '$item_no'";
		$result = mysqli_query($conn, $query);
		if(!$result){
			echo "Can't retrieve data " . mysqli_error($conn);
			exit;
		}
		return $result;
	}

	
	
	function getbookprice($itemno){
		$conn = db_connect();
		$query = "SELECT food_price FROM foods WHERE item_no = '$itemno'";
		$result = mysqli_query($conn, $query);
		if(!$result){
			echo "get food price failed! " . mysqli_error($conn);
			exit;
		}
		$row = mysqli_fetch_assoc($result);
		return $row['food_price'];
	}

	

	


	function getAll($conn){
		$query = "SELECT * from foods ORDER BY item_no ASC";
		$result = mysqli_query($conn, $query);
		if(!$result){
			echo "Can't retrieve data " . mysqli_error($conn);
			exit;
		}
		return $result;
	}
?>