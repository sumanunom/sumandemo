<?php
	$orderid = $_GET['orderid'];

	require_once "./functions/database_functions.php";
	$conn = db_connect();

	$query = "DELETE FROM order_items WHERE orderid = '$orderid'";
	$result = mysqli_query($conn, $query);
	/*  if(!$result){
		echo "delete data unsuccessfully " . mysqli_error($conn);
		exit;
	}
	header("Location: kitchen.php"); */
	try{
			//$register_result = mysqli_query($conn, $register_query);
			if($result){
				if(mysqli_affected_rows($conn)>0){
					echo "<script>alert(' YOUR ORDER BOOKED SUCCESSFULL !')</script>";
					
					?>
			<META HTTP-EQUIV="Refresh" CONTENT="0; URL=kitchen.php">
<?php
				}else{
					echo("Error in registration");
					 }		
		
				}
		}catch(Exception $ex){
									echo("error".$ex->getMessage());
							}
						
			 
?>