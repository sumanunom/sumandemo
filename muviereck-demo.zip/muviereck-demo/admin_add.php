<?php
	session_start();
	require_once "./functions/admin.php";
	$title = "Add new food";
	require "./template/header.php";
	require "./functions/database_functions.php";
	$conn = db_connect();

	if(isset($_POST['add'])){
		$item_no = trim($_POST['item_no']);
		$item_no = mysqli_real_escape_string($conn, $item_no);
		
		$food_name = trim($_POST['food_name']);
		$food_name = mysqli_real_escape_string($conn, $food_name);

		$cheff = trim($_POST['cheff']);
		$cheff = mysqli_real_escape_string($conn, $cheff);
		
		$food_descr = trim($_POST['food_descr']);
		$food_descr = mysqli_real_escape_string($conn, $food_descr);
		
		$food_price = floatval(trim($_POST['food_price']));
		$food_price = mysqli_real_escape_string($conn, $food_price);
		


		// add image
		if(isset($_FILES['image']) && $_FILES['image']['name'] != ""){
			$image = $_FILES['image']['name'];
			$directory_self = str_replace(basename($_SERVER['PHP_SELF']), '', $_SERVER['PHP_SELF']);
			$uploadDirectory = $_SERVER['DOCUMENT_ROOT'] . $directory_self . "bootstrap/img/";
			$uploadDirectory .= $image;
			move_uploaded_file($_FILES['image']['tmp_name'], $uploadDirectory);
		}




		$query = "INSERT INTO foods VALUES ('" . $item_no . "', '" . $food_name . "', '" . $cheff . "', '" . $image . "', '" . $food_descr . "', '" . $food_price . "')";
		$result = mysqli_query($conn, $query);
		if(!$result){
			echo "Can't add new data " . mysqli_error($conn);
			exit;
		} else {
			header("Location: index.php");
		}
	}
?>

<style >
	
form{
	max-width: 500px;
	margin: 0 auto;
	position: relative;
	top: 70px;
	background-color: darkgray;
	padding: 15px;
	border-radius: 10px;
	box-shadow: 5px 5px 5px rgba(0, 0, 0, 0.2);
	color: #333;
	display: flex;
	flex-direction: column;
}
.table{
	background-color: skyblue;
}


</style>
	<form method="post" action="admin_add.php" enctype="multipart/form-data">
		<table class="table">
			<tr>
				<th>List</th>
				<td><input type="text" name="item_no"></td>
			</tr>
			<tr>
				<th>Food Name</th>
				<td><input type="text" name="food_name" required></td>
			</tr>
			<tr>
				<th>Cheff</th>
				<td><input type="text" name="cheff" required></td>
			</tr>
			<tr>
				<th>Image</th>
				<td><input type="file" name="image"></td>
			</tr>
			<tr>
				<th>Description</th>
				<td><textarea name="food_descr" cols="40" rows="5"></textarea></td>
			</tr>
			<tr>
				<th>Price</th>
				<td><input type="text" name="food_price" required></td>
			</tr>
			
		</table>
		<input type="submit" name="add" value="Add new food" class="btn btn-primary">
		<input type="reset" value="cancel" class="btn btn-default">
	</form>
	<br/>
<?php
	
?>