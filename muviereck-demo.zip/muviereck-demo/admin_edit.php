<?php
	session_start();
	require_once "./functions/admin.php";
	$title = "Edit book";
	require_once "./template/header.php";
	require_once "./functions/database_functions.php";
	$conn = db_connect();

	if(isset($_GET['item_no'])){
		$item_no = $_GET['item_no'];
	} else {
		echo "Empty query!";
		exit;
	}

	if(!isset($item_no)){
		echo "Empty item no! check again!";
		exit;
	}

	// get book data
	$query = "SELECT * FROM foods WHERE item_no = '$item_no'";
	$result = mysqli_query($conn, $query);
	if(!$result){
		echo "Can't retrieve data " . mysqli_error($conn);
		exit;
	}
	$row = mysqli_fetch_assoc($result);
?>
	<form method="post" action="edit_food.php" enctype="multipart/form-data">
		<table class="table">
			<tr>
				<th>List</th>
				<td><input type="text" name="item_no" value="<?php echo $row['item_no'];?>" readOnly="true"></td>
			</tr>
			<tr>
				<th>Food Name</th>
				<td><input type="text" name="food_name" value="<?php echo $row['food_name'];?>" required></td>
			</tr>
			<tr>
				<th>Cheff</th>
				<td><input type="text" name="cheff" value="<?php echo $row['cheff'];?>" required></td>
			</tr>
			<tr>
				<th>Image</th>
				<td><input type="file" name="image"></td>
			</tr>
			<tr>
				<th>Description</th>
				<td><textarea name="food_descr" cols="40" rows="5"><?php echo $row['food_descr'];?></textarea>
			</tr>
			<tr>
				<th>Price</th>
				<td><input type="text" name="food_price" value="<?php echo $row['food_price'];?>" required></td>
			</tr>
		<!--	<tr>
				<th>Restaurant</th>
				<td><input type="text" name="publisher" value="<?php /* echo getPubName($conn, $row['publisherid']); */ ?>" required></td>
			</tr> -->
		</table>
		<input type="submit" name="save_change" value="Change" class="btn btn-primary">
		<input type="reset" value="cancel" class="btn btn-default">
	</form>
	<br/>
	<a href="admin_food.php" class="btn btn-success">Confirm</a>
